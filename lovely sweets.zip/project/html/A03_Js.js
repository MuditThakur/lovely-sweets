// A03_Js.js

// Function to format the price in Indian Rupees
function formatPrice(price) {
  return '₹' + price.toFixed(2);
}

// Function to confirm logout
function confirmLogout() {
  var confirmLogout = confirm("Are you sure you want to log out?");
  if (confirmLogout) {
    // Perform logout or redirection logic here
    alert("Logging out...");
  }
}

// Define arrays for each category with card data
const sweetsData = [
  { imageUrl: 'laddu.png', name: 'Motichur laddu', description: 'Delicious sweet treat', price: 350.00 },
  { imageUrl: 'kaju.png', name: 'Ghee Mysorepak', description: 'Premium cashew delight', price: 980.00 },
  { imageUrl: 'mysore.png', name: 'Kaju Katli', description: 'Mysore pak goodness', price: 1200.00 }
];

const namkeenData = [
  { imageUrl: 'bhakharwadi.jpg', name: 'Namkeen 1', description: 'Spicy and crunchy', price: 75.00 },
  { imageUrl: 'meetha.png', name: 'Namkeen 2', description: 'Chatpata mixture', price: 95.00 },
  { imageUrl: 'pudina.jpg', name: 'Namkeen 3', description: 'Savory namkeen snack', price: 85.00 }
];

const bakeryData = [
  { imageUrl: 'cookie.jpg', name: 'Bakery 1', description: 'Freshly baked goodness', price: 200.00 },
  { imageUrl: 'replace.jpg', name: 'Bakery 2', description: 'Flaky pastries', price: 125.00 },
  { imageUrl: 'replace.jpg', name: 'Bakery 3', description: 'Sweet and savory delights', price: 145.00 }
];

// Function to change the card deck based on the button clicked
function changeCardDeck(category) {
  var cardDeck = document.getElementById('cardDeck');

  // Choose the appropriate data array based on the category
  var selectedData = [];
  switch (category) {
    case 'sweets':
      selectedData = sweetsData;
      break;
    case 'namkeen':
      selectedData = namkeenData;
      break;
    case 'bakery':
      selectedData = bakeryData;
      break;
    default:
      // Default to sweets if category is not recognized
      selectedData = sweetsData;
  }

  // Clear previous cards
  cardDeck.innerHTML = '';

  selectedData.forEach(card => {
    cardDeck.innerHTML += `<div class="col-md-4">
                          <div class="card" style="width: 18rem;">
                            <img src="${card.imageUrl}" class="card-img-top" alt="${card.name}">
                            <div class="card-body">
                              <h5 class="card-title">${card.name}</h5>
                              <p class="card-text">${card.description}</p>
                              <p class="card-price">Price: ${formatPrice(card.price)}</p>
                              <a href="A03_shop.html" class="btn btn-primary">Buy Now</a>
                            </div>
                          </div>
                        </div>`;
  });
}
function openShop() {
  window.location.href = 'A03_shop.html';
}
